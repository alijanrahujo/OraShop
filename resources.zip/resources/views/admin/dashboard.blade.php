@extends('layouts.admin')
@section('title', 'Admin Dashboard')
@section('content')

    <livewire:close-day />

@endsection

